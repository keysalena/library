package com.keysalena.esemkapolice

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL

class Create : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create)

        findViewById<Button>(R.id.btnKirim).setOnClickListener {
            val jk = findViewById<EditText>(R.id.jk_et).text.toString()
            val nama = findViewById<EditText>(R.id.nama_et).text.toString()
            val buronan = findViewById<EditText>(R.id.buronan_et).text.toString()
            val golongan = findViewById<EditText>(R.id.golongan).text.toString()
            val kasus = findViewById<EditText>(R.id.kasus).text.toString()
            val kota = findViewById<EditText>(R.id.kota_et).text.toString()
            val hukuman = findViewById<EditText>(R.id.hukuman_et).text.toString()

            if (isValidInput(jk, nama, buronan, golongan, kasus, kota, hukuman)) {
                sendDataToServer(jk, nama, buronan, golongan, kasus, kota, hukuman)
            } else {
                Toast.makeText(this, "Invalid input, please fill all fields", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }
    private fun isValidInput(jk: String, nama: String, buronan: String, golongan: String, kasus: String, kota: String, hukuman: String): Boolean {
        return jk.isNotEmpty() && nama.isNotEmpty() && buronan.isNotEmpty() && golongan.isNotEmpty() && kasus.isNotEmpty() && kota.isNotEmpty() && hukuman.isNotEmpty()
    }

    private fun sendDataToServer(jk: String, nama: String, buronan: String, golongan: String, kasus: String, kota: String, hukuman: String) {
        GlobalScope.launch(Dispatchers.IO) {
            val url = URL("https://658d8f207c48dce947396725.mockapi.io/api/EsemkaPolice/Criminals")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")

            val json = JSONObject().apply {
                put("nama", nama)
                put("jenis_kelamin", jk)
                put("masih_buronan", buronan)
                put("golongan_kasus", golongan)
                put("kasus_kriminal", kasus)
                put("kota", kota)
                put("hukuman", hukuman)
            }
            Log.d("CEK", json.toString())

            try {
                val outputStream = DataOutputStream(conn.outputStream)
                outputStream.write(json.toString().toByteArray())
                outputStream.flush()

                if (conn.responseCode == HttpURLConnection.HTTP_CREATED) {
                    runOnUiThread {
                        Toast.makeText(this@Create, "Success Create Data", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@Create, MainActivity::class.java)
                        startActivity(intent)
                        Log.d("CEK_SUK", json.toString())

                    }
                } else {
                    Toast.makeText(this@Create, "Fail Create Data", Toast.LENGTH_SHORT).show()
                    Log.d("CEK_GA", json.toString())

                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                conn.disconnect()
            }
        }
    }
}
