﻿using System;
using System.Data;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Windows.Forms;

namespace SIMULASI_1
{
    public partial class FormSkillHero : Form
    {
        EsemkaHeroEntities entities = new EsemkaHeroEntities();
        bool isCreate = true;
        public FormSkillHero()
        {
            InitializeComponent();
        }

        private void FormSkillHero_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData()
        {
            heroSkillBindingSource1.Clear();
            heroSkillBindingSource1.AddNew();
            ApplyFilter();
            textBox2.Clear();
            textBox3.Clear();
        }
        private void ApplyFilter()
        {
            var filter = entities.HeroSkill
                .Where(p => p.Hero.Name.Contains(textBox1.Text))
                .OrderByDescending(p => p.ID)
                .ToList();
            heroSkillBindingSource.DataSource = filter;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormMenu formMenu = new FormMenu();
            formMenu.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (heroSkillBindingSource.Current is HeroSkill skill)
            {
                heroSkillBindingSource1.DataSource = skill;
                if (skill.Hero != null)
                {
                    textBox2.Text = skill.Hero.Name;
                }
                if (skill.Hero != null)
                {
                    textBox3.Text = skill.Skill.Name;
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {

                if (heroSkillBindingSource.Current is HeroSkill clan)
                {
                    var deleteClan = entities.HeroSkill.FirstOrDefault(h => h.ID == clan.ID);

                    if (deleteClan != null)
                    {
                        entities.HeroSkill.Remove(deleteClan);
                        entities.SaveChanges();
                        LoadData();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (heroSkillBindingSource1.Current is HeroSkill skill)
                {
                    if (isCreate)
                    {
                        var sa = entities.Hero.FirstOrDefault(c => c.Name == textBox2.Text);
                        skill.HeroID = sa.ID;
                        var ba = entities.Skill.FirstOrDefault(c => c.Name == textBox3.Text);
                        skill.SkillID = ba.ID;
                    }
                    entities.HeroSkill.AddOrUpdate(skill);
                    entities.SaveChanges();
                    LoadData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 sd = new Form1();
            sd.ShowDialog();

            string aaa = sd.heros;
            var skills = entities.HeroSkill.FirstOrDefault(o => o.Hero.Name == aaa && o.Skill.Name == textBox3.Text);
            if (skills != null)
            {
                MessageBox.Show($"Hero {aaa} sudah menggunakan {textBox3.Text}");
            }
            else
            {
                textBox2.Text = aaa;
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form2 sd = new Form2();
            sd.ShowDialog();

            string aaa = sd.Skils;
            var skills = entities.HeroSkill.FirstOrDefault(o => o.Hero.Name == textBox2.Text && o.Skill.Name == aaa);
            if (skills != null)
            {
                MessageBox.Show($"Skill {aaa} sudah di gunakan di Hero {textBox2.Text}");
            }
            else
            {
                textBox3.Text = aaa;
            }
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].DataBoundItem is HeroSkill s)
            {
                if (e.ColumnIndex == HeroClm.Index)
                {
                    e.Value = s.Hero.Name;
                }
                if (e.ColumnIndex == SkillClm.Index)
                {
                    e.Value = s.Skill.Name;
                }
                if (e.ColumnIndex == powerDataGridViewTextBoxColumn.Index)
                {
                    e.Value = s.Power.ToString("N0");
                }
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox4.Text, out _))
            {
                textBox4.Text = "";
            }
        }
    }
}
