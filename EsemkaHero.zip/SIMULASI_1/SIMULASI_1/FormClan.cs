﻿using System;
using System.Data;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Windows.Forms;

namespace SIMULASI_1
{
    public partial class FormClan : Form
    {
        EsemkaHeroEntities entities = new EsemkaHeroEntities();
        public FormClan()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (clanBindingSource.Current is Clan clan)
            {
                clanBindingSource1.DataSource = clan;
            }
        }

        private void FormClan_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData()
        {
            clanBindingSource1.Clear();
            clanBindingSource1.AddNew();
            ApplyFilter();
            textBox2.Clear();
            textBox3.Clear();
        }
        private void ApplyFilter()
        {
            var filter = entities.Clan
                .Where(p => p.Name.Contains(textBox1.Text))
                .OrderByDescending(p => p.ID)
                .ToList();
            clanBindingSource.DataSource = filter;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (clanBindingSource.Current is Clan clan)
                {
                    var deleteClan = entities.Clan.FirstOrDefault(h => h.ID == clan.ID);

                    if (deleteClan != null)
                    {
                        entities.Clan.Remove(deleteClan);
                        entities.SaveChanges();
                        LoadData();
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                if (clanBindingSource1.Current is Clan clann)
                {
                    entities.Clan.AddOrUpdate(clann);
                    entities.SaveChanges();
                    LoadData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormMenu formMenu = new FormMenu();
            formMenu.Show();
            this.Hide();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].DataBoundItem is Clan c)
            {
                if (e.ColumnIndex == descriptionDataGridViewTextBoxColumn.Index && c.Description == null)
                {
                    e.Value = "Unknown";
                }
            }
        }
    }
}
