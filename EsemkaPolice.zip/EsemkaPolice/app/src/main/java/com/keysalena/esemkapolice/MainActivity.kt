package com.keysalena.esemkapolice

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val createBtn = findViewById<Button>(R.id.createbtn)
        createBtn.setOnClickListener {
            val create = Intent(this, Create::class.java)
            startActivity(create)
        }

        val view = findViewById<RecyclerView>(R.id.criminal_list)

        GlobalScope.launch(Dispatchers.IO) {
            val url = URL("https://658d8f207c48dce947396725.mockapi.io/api/EsemkaPolice/Criminals")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"

            val result = conn.inputStream.bufferedReader().readLines().toString()
            val json = JSONArray(result).getJSONArray(0)

            GlobalScope.launch(Dispatchers.Main) {
                val itemAdapter = ItemAdapter(json)
                view.adapter = itemAdapter
                view.layoutManager = LinearLayoutManager(this@MainActivity)
            }
        }
    }

    class ItemAdapter(private val items: JSONArray) : RecyclerView.Adapter<ItemAdapter.ItemViewHolder>() {

        class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val namaPelaku: TextView = view.findViewById(R.id.id_tv)
            val namaKasus: TextView = view.findViewById(R.id.nama_tv)
            val buttonView: Button = view.findViewById(R.id.buttonView)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
            val layoutInflater = LayoutInflater.from(parent.context)
            val view = layoutInflater.inflate(R.layout.firstpage, parent, false)
            return ItemViewHolder(view)
        }

        override fun getItemCount(): Int {
            return items.length()
        }

        override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
            val item = items.getJSONObject(position)
            holder.namaPelaku.text = item.getString("nama")
            holder.namaKasus.text = item.getString("kasus_kriminal")

            holder.buttonView.setOnClickListener {
                val context = holder.itemView.context
                val createIntent = Intent(context, com.keysalena.esemkapolice.View::class.java)
                createIntent.putExtra("nama", item.getString("nama"))
                createIntent.putExtra("jk", item.getString("jenis_kelamin"))
                createIntent.putExtra("mb", item.getString("masih_buronan"))
                createIntent.putExtra("gk", item.getString("golongan_kasus"))
                createIntent.putExtra("kk", item.getString("kasus_kriminal"))
                createIntent.putExtra("kota", item.getString("kota"))
                createIntent.putExtra("hukuman", item.getString("hukuman"))
                context.startActivity(createIntent)
            }
        }
    }
}
