﻿namespace SIMULASI_1
{
    partial class FormReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.fightHistoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Hero1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Hero2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Hero1TotalPower = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Hero2TotalPower = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hero1IDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hero2IDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hero1TotalPowerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hero2TotalPowerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateClm = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.heroDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hero1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fightHistoryBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(23, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(61, 23);
            this.button1.TabIndex = 77;
            this.button1.Text = "Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Location = new System.Drawing.Point(24, 48);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(186, 20);
            this.textBox1.TabIndex = 69;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeight = 30;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Hero1,
            this.Hero2,
            this.Hero1TotalPower,
            this.Hero2TotalPower,
            this.iDDataGridViewTextBoxColumn,
            this.hero1IDDataGridViewTextBoxColumn,
            this.hero2IDDataGridViewTextBoxColumn,
            this.hero1TotalPowerDataGridViewTextBoxColumn,
            this.hero2TotalPowerDataGridViewTextBoxColumn,
            this.DateClm,
            this.heroDataGridViewTextBoxColumn,
            this.hero1DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.fightHistoryBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(27, 84);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToFirstHeader;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(761, 207);
            this.dataGridView1.TabIndex = 76;
            this.dataGridView1.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridView1_CellFormatting);
            // 
            // fightHistoryBindingSource
            // 
            this.fightHistoryBindingSource.DataSource = typeof(SIMULASI_1.FightHistory);
            // 
            // Hero1
            // 
            this.Hero1.HeaderText = "Hero 1";
            this.Hero1.Name = "Hero1";
            this.Hero1.ReadOnly = true;
            // 
            // Hero2
            // 
            this.Hero2.HeaderText = "Hero2";
            this.Hero2.Name = "Hero2";
            this.Hero2.ReadOnly = true;
            // 
            // Hero1TotalPower
            // 
            this.Hero1TotalPower.DataPropertyName = "Hero1TotalPower";
            this.Hero1TotalPower.HeaderText = "Total Power Hero 1";
            this.Hero1TotalPower.Name = "Hero1TotalPower";
            this.Hero1TotalPower.ReadOnly = true;
            // 
            // Hero2TotalPower
            // 
            this.Hero2TotalPower.DataPropertyName = "Hero2TotalPower";
            this.Hero2TotalPower.HeaderText = "Total Power Hero 1";
            this.Hero2TotalPower.Name = "Hero2TotalPower";
            this.Hero2TotalPower.ReadOnly = true;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDDataGridViewTextBoxColumn.Visible = false;
            // 
            // hero1IDDataGridViewTextBoxColumn
            // 
            this.hero1IDDataGridViewTextBoxColumn.DataPropertyName = "Hero1ID";
            this.hero1IDDataGridViewTextBoxColumn.HeaderText = "Hero1ID";
            this.hero1IDDataGridViewTextBoxColumn.Name = "hero1IDDataGridViewTextBoxColumn";
            this.hero1IDDataGridViewTextBoxColumn.ReadOnly = true;
            this.hero1IDDataGridViewTextBoxColumn.Visible = false;
            // 
            // hero2IDDataGridViewTextBoxColumn
            // 
            this.hero2IDDataGridViewTextBoxColumn.DataPropertyName = "Hero2ID";
            this.hero2IDDataGridViewTextBoxColumn.HeaderText = "Hero2ID";
            this.hero2IDDataGridViewTextBoxColumn.Name = "hero2IDDataGridViewTextBoxColumn";
            this.hero2IDDataGridViewTextBoxColumn.ReadOnly = true;
            this.hero2IDDataGridViewTextBoxColumn.Visible = false;
            // 
            // hero1TotalPowerDataGridViewTextBoxColumn
            // 
            this.hero1TotalPowerDataGridViewTextBoxColumn.DataPropertyName = "Hero1TotalPower";
            this.hero1TotalPowerDataGridViewTextBoxColumn.HeaderText = "Hero1TotalPower";
            this.hero1TotalPowerDataGridViewTextBoxColumn.Name = "hero1TotalPowerDataGridViewTextBoxColumn";
            this.hero1TotalPowerDataGridViewTextBoxColumn.ReadOnly = true;
            this.hero1TotalPowerDataGridViewTextBoxColumn.Visible = false;
            // 
            // hero2TotalPowerDataGridViewTextBoxColumn
            // 
            this.hero2TotalPowerDataGridViewTextBoxColumn.DataPropertyName = "Hero2TotalPower";
            this.hero2TotalPowerDataGridViewTextBoxColumn.HeaderText = "Hero2TotalPower";
            this.hero2TotalPowerDataGridViewTextBoxColumn.Name = "hero2TotalPowerDataGridViewTextBoxColumn";
            this.hero2TotalPowerDataGridViewTextBoxColumn.ReadOnly = true;
            this.hero2TotalPowerDataGridViewTextBoxColumn.Visible = false;
            // 
            // DateClm
            // 
            this.DateClm.DataPropertyName = "FightDate";
            this.DateClm.HeaderText = "Fight Date";
            this.DateClm.Name = "DateClm";
            this.DateClm.ReadOnly = true;
            // 
            // heroDataGridViewTextBoxColumn
            // 
            this.heroDataGridViewTextBoxColumn.DataPropertyName = "Hero";
            this.heroDataGridViewTextBoxColumn.HeaderText = "Hero";
            this.heroDataGridViewTextBoxColumn.Name = "heroDataGridViewTextBoxColumn";
            this.heroDataGridViewTextBoxColumn.ReadOnly = true;
            this.heroDataGridViewTextBoxColumn.Visible = false;
            // 
            // hero1DataGridViewTextBoxColumn
            // 
            this.hero1DataGridViewTextBoxColumn.DataPropertyName = "Hero1";
            this.hero1DataGridViewTextBoxColumn.HeaderText = "Hero1";
            this.hero1DataGridViewTextBoxColumn.Name = "hero1DataGridViewTextBoxColumn";
            this.hero1DataGridViewTextBoxColumn.ReadOnly = true;
            this.hero1DataGridViewTextBoxColumn.Visible = false;
            // 
            // FormReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 310);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "FormReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormReport";
            this.Load += new System.EventHandler(this.FormReport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fightHistoryBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource fightHistoryBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn Hero1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Hero2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Hero1TotalPower;
        private System.Windows.Forms.DataGridViewTextBoxColumn Hero2TotalPower;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hero1IDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hero2IDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hero1TotalPowerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hero2TotalPowerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateClm;
        private System.Windows.Forms.DataGridViewTextBoxColumn heroDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hero1DataGridViewTextBoxColumn;
    }
}