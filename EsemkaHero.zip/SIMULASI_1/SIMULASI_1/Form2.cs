﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIMULASI_1
{
    public partial class Form2 : Form
    {
        EsemkaHeroEntities entities = new EsemkaHeroEntities();
        public string Skils { get; private set; }

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.Rows.Count)
            {
                object cellValue = dataGridView1.Rows[e.RowIndex].Cells[0].Value;

                Skils = cellValue?.ToString();

                this.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void ApplyFilter()
        {
            var filter = entities.Skill
                .Where(p => p.Name.Contains(textBox1.Text))
                .ToList();
            skillBindingSource.DataSource = filter;
        }
    }
}
