﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace SIMULASI_1
{
    public partial class FormReport : Form
    {
        EsemkaHeroEntities entities = new EsemkaHeroEntities();
        public FormReport()
        {
            InitializeComponent();
        }

        private void FormReport_Load(object sender, EventArgs e)
        {

            ApplyFilter();

        }

        private void ApplyFilter()
        {
            var filter = entities.FightHistory
                .Where(p => p.Hero.Name.Contains(textBox1.Text))
                .ToList().OrderByDescending(l => l.ID);
            fightHistoryBindingSource.DataSource = filter;
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].DataBoundItem is FightHistory fightHistory)
            {
                if (e.ColumnIndex == Hero1.Index)
                {
                    Hero hero1 = entities.Hero.FirstOrDefault(h => h.ID == fightHistory.Hero1ID);
                    e.Value = hero1?.Name;
                }
                if (e.ColumnIndex == Hero2.Index)
                {
                    Hero hero2 = entities.Hero.FirstOrDefault(h => h.ID == fightHistory.Hero2ID);
                    e.Value = hero2?.Name;
                }   
                if (e.ColumnIndex == DateClm.Index)
                {
                    e.Value = fightHistory.FightDate.ToString("dd MMM yyyy");
                    e.FormattingApplied = true;
                }
                if (e.ColumnIndex == Hero1TotalPower.Index)
                {
                    e.Value = fightHistory.Hero1TotalPower.ToString("N0");
                }
                if (e.ColumnIndex == Hero2TotalPower.Index)
                {
                    e.Value = fightHistory.Hero2TotalPower.ToString("N0");
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormMenu formMenu = new FormMenu();
            formMenu.Show();
            this.Hide();
        }
    }
}
