﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Migrations;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SIMULASI_1
{
    public partial class FormElement : Form
    {
        EsemkaHeroEntities entities = new EsemkaHeroEntities();
        public FormElement()
        {
            InitializeComponent();
        }

        private void FormElement_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData()
        {
            elementBindingSource1.Clear();
            elementBindingSource1.AddNew();
            ApplyFilter();
            textBox2.Clear();
        }
        private void ApplyFilter()
        {
            var filter = entities.Element
                .Where(p => p.Element1.Contains(textBox1.Text))
                .OrderByDescending(p => p.ID)
                .ToList();
            elementBindingSource.DataSource = filter;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ApplyFilter ();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (elementBindingSource.Current is Element elem)
            {
                elementBindingSource1.DataSource = elem;
            }
        }


        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (elementBindingSource1.Current is Element elem)
                {
                    entities.Element.AddOrUpdate(elem);
                    entities.SaveChanges();
                    LoadData();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            
        }


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
            if (elementBindingSource.Current is Element elem)
            {
                var deleteElement = entities.Element.FirstOrDefault(h => h.ID == elem.ID);

                if (deleteElement != null)
                {
                    entities.Element.Remove(deleteElement);
                    entities.SaveChanges();
                    LoadData();
                }
            }

            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormMenu formMenu = new FormMenu();
            formMenu.Show();
            this.Hide();
        }
    }
}
