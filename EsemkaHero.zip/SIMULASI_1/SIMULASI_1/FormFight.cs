﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace SIMULASI_1
{
    public partial class FormFight : Form
    {
        EsemkaHeroEntities entities = new EsemkaHeroEntities();
        public FormFight()
        {
            InitializeComponent();
        }

        private void FormFight_Load(object sender, EventArgs e)
        {
            ApplyFilter();
            ApplyFilter2();
        }

        private void ApplyFilter()
        {
            comboSkill1.Items.Clear();

            var selectName = textBox2.Text;

            if (!string.IsNullOrEmpty(selectName))
            {
                var skills = entities.HeroSkill
                    .Where(o => o.Hero.Name == selectName)
                    .Select(o => o.Skill.Name)
                    .ToList();

                comboSkill1.Items.AddRange(skills.ToArray());
            }
        }
        private void ApplyFilter2()
        {
            comboSkill2.Items.Clear();

            var selectName2 = textBox1.Text;

            if (!string.IsNullOrEmpty(selectName2))
            {
                var skills = entities.HeroSkill
                    .Where(o => o.Hero.Name == selectName2)
                    .Select(o => o.Skill.Name)
                    .ToList();

                comboSkill2.Items.AddRange(skills.ToArray());
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormMenu formMenu = new FormMenu();
            formMenu.Show();
            this.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 sd = new Form1();
            sd.ShowDialog();

            string aaa = sd.heros;

            if (textBox1.Text == aaa)
            {
                MessageBox.Show($"Hero {aaa} sudah digunakan silahkan pilih yang lain");
            }
            else
            {
                textBox2.Text = aaa;
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 sd = new Form1();
            sd.ShowDialog();

            string aaa = sd.heros;

            if (textBox2.Text == aaa)
            {
                MessageBox.Show($"Hero {aaa} sudah digunakan silahkan pilih yang lain");
            }
            else
            {
                textBox1.Text = aaa;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

            dataGridView1.Rows.Add();

            int rowIndex = dataGridView1.Rows.Count - 1;

            var selectedSkillName = comboSkill1.Text;
            comboSkill1.Items.Remove(selectedSkillName);

            var power = entities.HeroSkill
                .Where(p => p.Hero.Name == textBox2.Text && p.Skill.Name == selectedSkillName)
                .FirstOrDefault();

            dataGridView1.Rows[rowIndex].Cells[0].Value = selectedSkillName;
            dataGridView1.Rows[rowIndex].Cells[1].Value = power.Power;
            PowerAmount1();
            Winner();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ApplyFilter2();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

            dataGridView2.Rows.Add();

            int rowIndex = dataGridView2.Rows.Count - 1;

            var selectedSkillName = comboSkill2.Text;
            comboSkill2.Items.Remove(selectedSkillName);

            var power = entities.HeroSkill
                .Where(p => p.Hero.Name == textBox1.Text && p.Skill.Name == selectedSkillName)
                .FirstOrDefault();

            dataGridView2.Rows[rowIndex].Cells[0].Value = selectedSkillName;
            dataGridView2.Rows[rowIndex].Cells[1].Value = power.Power.ToString("N0");
            PowerAmount2();
            Winner();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void textPower1_TextChanged(object sender, EventArgs e)
        {
            PowerAmount1();
        }

        private void PowerAmount1()
        {
            int totalPower = 0;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.Cells[1].Value != null && int.TryParse(row.Cells[1].Value.ToString().Replace(".", ""), out int power))
                {
                    totalPower += power;
                }
            }
            textPower1.Text = totalPower.ToString("N0");
        }

        private void PowerAmount2()
        {
            int totalPower = 0;

            foreach (DataGridViewRow row in dataGridView2.Rows)
            {
                if (row.Cells[1].Value != null && int.TryParse(row.Cells[1].Value.ToString().Replace(".", ""), out int power))
                {
                    totalPower += power;
                }
            }
            textPower2.Text = totalPower.ToString("N0");
        }

        private void textPower2_TextChanged(object sender, EventArgs e)
        {
            PowerAmount2();
        }

        private void textWinner_TextChanged(object sender, EventArgs e)
        {
            Winner();
        }

        private void Winner()
        {
            if (int.TryParse(textPower1.Text.Replace(".",""), out int power1) && int.TryParse(textPower2.Text.Replace(".", ""), out int power2))
            {
                if (power1 > power2)
                {
                    textWinner.Text = textBox2.Text;
                }
                else if (power2 > power1)
                {
                    textWinner.Text = textBox1.Text;
                }
                else
                {
                    textWinner.Text = "Draw";
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

            int heroID1 = entities.Hero.Where(h => h.Name == textBox2.Text).Select(h => h.ID).FirstOrDefault();
            int heroID2 = entities.Hero.Where(h => h.Name == textBox1.Text).Select(h => h.ID).FirstOrDefault();

            if (int.TryParse(textPower1.Text.Replace(".",""), out int power1) && int.TryParse(textPower2.Text.Replace(".",""), out int power2))
            {
                FightHistory fh = new FightHistory
                {
                    Hero1ID = heroID1,
                    Hero2ID = heroID2,
                    Hero1TotalPower = power1,
                    Hero2TotalPower = power2,
                    FightDate = DateTime.Now,
                };
                entities.FightHistory.Add(fh);
                entities.SaveChanges();
                FormReport n = new FormReport();
                n.Show();
                this.Hide();
            }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}