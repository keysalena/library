﻿using System;
using System.Data;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Windows.Forms;

namespace SIMULASI_1
{
    public partial class FormHero : Form
    {
        EsemkaHeroEntities entities = new EsemkaHeroEntities();
        bool isCreate = true;
        public string heros { get; private set; }
        public FormHero()
        {
            InitializeComponent();
        }

        private void FormHero_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            bindingSource1.Clear();
            bindingSource1.AddNew();
            ApplyFilter();
            textBox2.Clear();
            Desc.Clear();
            ComboBoxLoad();
        }
        private void ComboBoxLoad()
        {
            comboBox1.Items.Clear();
            var clans = entities.Clan.ToList();

            foreach (var clan in clans)
            {
                comboBox1.Items.Add(clan.Name);
                comboBox2.Items.Add(clan.Name);
            }
        }
        private void ApplyFilter()
        {
            var filter = entities.Hero
                .Where(p =>
                    (p.Name.Contains(textBox1.Text) || textBox1.Text == "") &&
                    (p.Clan != null && p.Clan.Name.Contains(comboBox2.Text) || comboBox2.Text == "")
                )
                .OrderByDescending(p => p.ID)
                .ToList();

            heroBindingSource.DataSource = filter;
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (heroBindingSource.Current is Hero selectedHero)
            {
                bindingSource1.DataSource = selectedHero;

                if (selectedHero.Clan != null)
                {
                    comboBox1.Text = selectedHero.Clan.Name;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
            if (bindingSource1.Current is Hero heroo)
            {
                if (isCreate)
                {
                        if (comboBox1.SelectedItem == null)
                        {
                            heroo.ClanID = null;
                        }
                        else
                        {
                            var clan = entities.Clan.FirstOrDefault(c => c.Name == comboBox1.Text);
                            heroo.ClanID = clan.ID;
                        }
                        heroo.BirthDate = dateTimePicker1.Value;
                }
                entities.Hero.AddOrUpdate(heroo);
                entities.SaveChanges();
                LoadData();
            }
            }catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (heroBindingSource.Current is Hero hr)
                {
                    var heroToDelete = entities.Hero.FirstOrDefault(h => h.ID == hr.ID);

                    if (heroToDelete != null)
                    {
                        entities.Hero.Remove(heroToDelete);
                        entities.SaveChanges();
                        LoadData();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }        

        private void button4_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].DataBoundItem is Hero hero)
            {
                if (e.ColumnIndex == ClanClm.Index && hero.Clan != null)
                {
                    e.Value = hero.Clan.Name;
                }  
                if (e.ColumnIndex == ClanClm.Index && hero.ClanID == null)
                {
                    e.Value = "Unknown";
                }
                if (e.ColumnIndex == descriptionDataGridViewTextBoxColumn.Index && hero.Description == null)
                {
                    e.Value = "Unknown";
                }
                if (e.ColumnIndex == birthclm.Index)
                {
                    e.Value = hero.BirthDate.ToString("dd MMM yyyy");
                    e.FormattingApplied = true;
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormMenu formMenu = new FormMenu();
            formMenu.Show();
            this.Hide();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            comboBox2.SelectedItem = null;
        }
    }
}
