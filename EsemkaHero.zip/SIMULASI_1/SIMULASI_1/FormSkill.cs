﻿using System;
using System.Data;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Windows.Forms;

namespace SIMULASI_1
{
    public partial class FormSkill : Form
    {
        public string Skils { get; set; }
        EsemkaHeroEntities entities = new EsemkaHeroEntities();
        bool isCreate = true;

        public FormSkill()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormMenu formMenu = new FormMenu();
            formMenu.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].DataBoundItem is Skill s)
            {
                if (e.ColumnIndex == ElementClm.Index && s.Element != null)
                {
                    e.Value = s.Element.Element1;
                }
                if (e.ColumnIndex == ElementClm.Index && s.Element == null)
                {
                    e.Value = "Unknown";
                }
                if (e.ColumnIndex == Description.Index && s.Description == null)
                {
                    e.Value = "Unknown";
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (skillBindingSource.Current is Skill skill)
            {
                skillBindingSource1.DataSource = skill;
                if (skill.Element != null)
                {
                    comboBox2.Text = skill.Element.Element1;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                if (skillBindingSource.Current is Skill skill)
                {
                    var delete = entities.Skill.FirstOrDefault(h => h.ID == skill.ID);

                    if (delete != null)
                    {
                        entities.Skill.Remove(delete);
                        entities.SaveChanges();
                        LoadData();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void FormSkill_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private void LoadData()
        {
            skillBindingSource1.Clear();
            skillBindingSource1.AddNew();
            ApplyFilter();
            textBox2.Clear();
            textBox3.Clear();
            comboBox2.Items.Clear();
            ComboBoxLoad();
            dataGridView1.Columns[1].Width = 360;
        }

        private void ComboBoxLoad()
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();

            var elem = entities.Element.ToList();

            foreach (var ele in elem)
            {
                comboBox2.Items.Add(ele.Element1);
                comboBox3.Items.Add(ele.Element1);
            }
            comboBox1.Items.Add("Easy");
            comboBox1.Items.Add("Medium");
            comboBox1.Items.Add("Hard");
            comboBox1.Items.Add("Supreme");
        }

        private void ApplyFilter()
        {
            var filter = entities.Skill
                  .Where(p =>
                    (p.Name.Contains(textBox1.Text) || textBox1.Text == "") &&
                    (p.Element != null && p.Element.Element1.Contains(comboBox3.Text) || comboBox3.Text == "")
                ).OrderByDescending(p => p.ID)
                .ToList();
            skillBindingSource.DataSource = filter;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                if (skillBindingSource1.Current is Skill skill)
                {
                    if (isCreate)
                    {
                        if (comboBox2.SelectedItem == null)
                        {
                            skill.ElementID = null;
                        }
                        else
                        {
                        var sa = entities.Element.FirstOrDefault(c => c.Element1 == comboBox2.Text);
                        skill.ElementID = sa.ID;
                        }
                    }
                    entities.Skill.AddOrUpdate(skill);
                    entities.SaveChanges();
                    LoadData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.Rows.Count)
            {
                object cellValue = dataGridView1.Rows[e.RowIndex].Cells[0].Value;

                Skils = cellValue?.ToString();

                this.Close();
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyFilter();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            comboBox3.SelectedItem = null;
            textBox1.Clear();
        }
    }
}
