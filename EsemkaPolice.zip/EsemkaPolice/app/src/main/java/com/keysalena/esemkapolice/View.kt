package com.keysalena.esemkapolice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class View : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view)

        val nama = findViewById<TextView>(R.id.nama_v)
        val jenis = findViewById<TextView>(R.id.jk_v)
        val buronan = findViewById<TextView>(R.id.buronan_v)
        val golongan = findViewById<TextView>(R.id.golongan_v)
        val kasus = findViewById<TextView>(R.id.kasus_v)
        val kota = findViewById<TextView>(R.id.kota_v)
        val hukuman = findViewById<TextView>(R.id.hukuman_v)

        val namaV = intent.getStringExtra("nama")
        val jkV = intent.getStringExtra("jk")
        val buronanV = intent.getStringExtra("mb")
        val golonganV = intent.getStringExtra("gk")
        val kasusV = intent.getStringExtra("kk")
        val kotaV = intent.getStringExtra("kota")
        val hukumanV = intent.getStringExtra("hukuman")

        nama.text = namaV
        jenis.text = jkV
        buronan.text = buronanV
        golongan.text = golonganV
        kasus.text = kasusV
        kota.text = kotaV
        hukuman.text = hukumanV

        findViewById<Button>(R.id.btnBack).setOnClickListener {
            finish()
        }
    }
}